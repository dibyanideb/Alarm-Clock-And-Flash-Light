package com.utilte.projectintrn;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Setting extends AppCompatActivity {

    private ToggleButton t;
    private long milli;
    private int day;
    private int hour;
    private int min;
    private int month;
    private int year;
    private String hm;
    private String mm;
    private TextView t1;
    private TextView t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        t = findViewById(R.id.onoff);
        t1 = findViewById(R.id.hr);
        t2 = findViewById(R.id.mt);

        FirebaseDatabase.getInstance().getReference().child("alrm").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                alrm value = dataSnapshot.getValue(alrm.class);
                milli = value.getMilli();
                day = value.getDay();
                hour = value.getHour();
                min = value.getMin();
                month = value.getMonth();
                year = value.getYear();
                hm = ""+hour;
                mm = ""+min;
                t1.setText(hm);
                t2.setText(mm);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });




        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(t.getText().equals("OFF"))
                {
                    alrm x=new alrm(hour,min,0,day,month,year,milli);
                    FirebaseDatabase.getInstance().getReference().child("alrm").setValue(x);
                }
                else if(t.getText().equals("ON")){
                    alrm x=new alrm(hour,min,1,day,month,year,milli);
                    FirebaseDatabase.getInstance().getReference().child("alrm").setValue(x);
                }
            }
        });
        Button s=findViewById(R.id.button5);
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c=new Intent(Setting.this,Date.class);
                startActivity(c);
            }
        });
    }
}
