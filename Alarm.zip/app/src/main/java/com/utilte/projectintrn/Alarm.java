package com.utilte.projectintrn;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class Alarm extends AppCompatActivity {

    public Button b;
    private int hour;
    private int minute;
    private long xm;
    private TimePicker t;
    boolean q= true;
    private Button of;
    private PendingIntent p;
    private AlarmManager a;
    private int dayOfMonth;
    private int month;
    private int year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
        b = findViewById(R.id.button2);
        t = findViewById(R.id.timePicker);

        int syshr = Calendar.getInstance().getTime().getHours();
        int sysmin= Calendar.getInstance().getTime().getMinutes();
        of = findViewById(R.id.button4);
        of.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent neq=new Intent(Alarm.this,Setting.class);
                startActivity(neq);
            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hour = t.getHour();
                minute = t.getMinute();
                Calendar m=Calendar.getInstance();
                dayOfMonth = m.get(Calendar.DAY_OF_MONTH);
                month = m.get(Calendar.MONTH)+1;
                year = m.get(Calendar.YEAR);
                Calendar c=Calendar.getInstance();
                c.set(Calendar.HOUR_OF_DAY,hour);
                c.set(Calendar.MINUTE,minute);

                xm=c.getTimeInMillis();

                alrm data=new alrm(hour,minute,0, dayOfMonth, month, year,xm);
                FirebaseDatabase.getInstance().getReference().child("alrm").setValue(data);
                Intent x=new Intent(Alarm.this,AlarmRecvr.class);
                p = PendingIntent.getBroadcast(getApplicationContext(),0,x,0);
                a = (AlarmManager)getSystemService(ALARM_SERVICE);
                FirebaseDatabase.getInstance().getReference().child("alrm").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        alrm value = dataSnapshot.getValue(alrm.class);
                        long milli = value.getMilli();
                        a.setExact(AlarmManager.RTC_WAKEUP,milli,p);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

            }
        });



    }
}
