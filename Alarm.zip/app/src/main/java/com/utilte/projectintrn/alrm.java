package com.utilte.projectintrn;

/**
 * Created by lenovo on 12/13/2017.
 */

public class alrm {
    public alrm(int repeat) {
        this.repeat = repeat;
    }

    private int hour;
    private int min;

    public alrm() {
    }

    public alrm(int hour, int min, int repeat, int day, int month, long milli) {
        this.hour = hour;
        this.min = min;
        this.repeat = repeat;
        this.day = day;
        this.month = month;
        this.milli = milli;
    }

    public int getHour() {
        return hour;

    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getRepeat() {
        return repeat;
    }

    public void setRepeat(int repeat) {
        this.repeat = repeat;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public long getMilli() {
        return milli;
    }

    public void setMilli(long milli) {
        this.milli = milli;
    }

    public alrm(int hour, int min, int repeat, int day, int month, int year, long milli) {

        this.hour = hour;
        this.min = min;

        this.repeat = repeat;
        this.day = day;
        this.month = month;
        this.year = year;
        this.milli = milli;
    }

    private int repeat;
    private int day;
    private int month;
    private int year;
    private long milli;


}
