package com.utilte.projectintrn;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class Date extends AppCompatActivity {
    private long milli;
    private int day;
    private int hour;
    private int min;
    private int month;
    private int year;
    private int repeat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date);
        FirebaseDatabase.getInstance().getReference().child("alrm").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                alrm value = dataSnapshot.getValue(alrm.class);
                milli = value.getMilli();
                day = value.getDay();
                hour = value.getHour();
                min = value.getMin();
                month = value.getMonth();
                year = value.getYear();
                repeat = value.getRepeat();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        Button b=findViewById(R.id.button6);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePicker db=findViewById(R.id.datePicker);
                int dayOfMonth = db.getDayOfMonth();
                int month = db.getMonth();
                int year = db.getYear();
                Calendar c=Calendar.getInstance();
                c.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                c.set(Calendar.MONTH,month);
                c.set(Calendar.YEAR,year);
                c.set(Calendar.HOUR_OF_DAY,hour);
                c.set(Calendar.MINUTE,min);
                long timeInMillis = c.getTimeInMillis();
                alrm data=new alrm(hour,min,repeat, dayOfMonth, month, year,timeInMillis);
                FirebaseDatabase.getInstance().getReference().child("alrm").setValue(data);
                finish();

            }
        });

    }
}
