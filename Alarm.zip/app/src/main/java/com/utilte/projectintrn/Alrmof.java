package com.utilte.projectintrn;

import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class Alrmof extends AppCompatActivity {

    private Boolean state=true;
    private MediaPlayer player;
    private Vibrator v;
    private Vibrator x;
    private long milli;
    private int day;
    private int hour;
    private int min;
    private int month;
    private int year;
    private int repeat;
	private boolean doonc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alrmof);
        Button b1 = findViewById(R.id.alrmst);

            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    player.stop();
                    finish();

                }
            });
            doonc=true;
            playsng();

        }

    private void playsng() {
        Uri alrm = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        player = MediaPlayer.create(this, alrm);
        player.setLooping(true);
        player.start();
        FirebaseDatabase.getInstance().getReference().child("alrm").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                alrm value = dataSnapshot.getValue(alrm.class);
                milli = value.getMilli();
                day = value.getDay();
                hour = value.getHour();
                min = value.getMin();
                month = value.getMonth();
                year = value.getYear();
                repeat = value.getRepeat();
                if(repeat==1&&doonc==true) {
                    int i = day + 1;
                    Calendar c = Calendar.getInstance();
                    c.set(Calendar.DAY_OF_MONTH, i);
                    c.set(Calendar.HOUR_OF_DAY, hour);
                    c.set(Calendar.MINUTE, min);
                    long timeInMillis = c.getTimeInMillis();
                    alrm data = new alrm(hour, min, 1, i, month, year, timeInMillis);
                    FirebaseDatabase.getInstance().getReference().child("alrm").setValue(data);
					doonc=false;
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        }

}

