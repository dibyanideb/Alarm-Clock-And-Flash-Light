package com.utilte.projectintrn;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.Camera;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FlashLight extends AppCompatActivity {

    private android.hardware.Camera c;
    private boolean flashpresent;
    boolean flashon;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flash_light);
        final Button b=(Button)findViewById(R.id.button);
        boolean b1 = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        if(!b1)
        {
            requestPermissions(new String []{Manifest.permission.CAMERA},25);

    }
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(flashon!=true)
                {
                    try {
                        if (getPackageManager().hasSystemFeature(
                                PackageManager.FEATURE_CAMERA_FLASH)) {
                            Camera cam = Camera.open();
                            Camera.Parameters p = cam.getParameters();
                            p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                            cam.setParameters(p);
                            cam.startPreview();
                            b.setBackgroundResource(R.drawable.btnon);
                            b.setText("Turn Off");
                            b.setTextColor(Color.WHITE);
                            flashon=true;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getBaseContext(), "Cannt be truned on",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                else if(flashon==true){
                    try {
                        if (getPackageManager().hasSystemFeature(
                                PackageManager.FEATURE_CAMERA_FLASH)) {
                            Camera cam = Camera.open();
                            Camera.Parameters p = cam.getParameters();
                            p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                            cam.setParameters(p);
                            cam.startPreview();
                            b.setText("Turn On");
                            b.setTextColor(Color.WHITE);
                            b.setBackgroundResource(R.drawable.btn);
                            flashon=false;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getBaseContext(), "Cannt be truned on",
                                Toast.LENGTH_SHORT).show();
                    }


                }

            }
        });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==25)
        {
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                flashpresent =true;
            }
        }
    }



    }

